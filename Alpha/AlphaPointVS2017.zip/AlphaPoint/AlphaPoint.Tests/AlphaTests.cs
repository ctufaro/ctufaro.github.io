﻿using System;
using System.Collections.Generic;
using AlphaPoint.ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AlphaPoint.Tests
{
    [TestClass]
    public class AlphaTests
    {
        #region Problem 1 Test Cases
        [TestMethod]
        public void Interverse_GivenRandomString1_ReturnsInterwoven()
        {
            string interwoven = StringMethods.Interverse("alpha");
            Assert.AreEqual("aalhpphlaa", interwoven);
        }

        [TestMethod]
        public void Interverse_GivenRandomString2_ReturnsInterwoven()
        {
            string interwoven = StringMethods.Interverse("ab12");
            Assert.AreEqual("a2b11b2a", interwoven);
        }

        [TestMethod]
        public void Interverse_GivenRandomString3_ReturnsInterwoven()
        {
            string interwoven = StringMethods.Interverse("racecar");
            Assert.AreEqual("rraacceeccaarr", interwoven);
        }

        [TestMethod]
        public void Interverse_GivenEmptyString_ReturnsEmptyString()
        {
            string interwoven = StringMethods.Interverse("");
            Assert.AreEqual("", interwoven);
        }

        [TestMethod]
        public void Interverse_GivenSingleString_ReturnsInterwoven()
        {
            string interwoven = StringMethods.Interverse("x");
            Assert.AreEqual("xx", interwoven);
        }

        [TestMethod]
        public void Interverse_GivenNull_ReturnsEmptyString()
        {
            string interwoven = StringMethods.Interverse(null);
            Assert.AreEqual("", interwoven);
        }
        #endregion

        #region Problem 2 Test Cases
        [TestMethod]
        public void Palindrome_GivenPalindromeString1_ReturnsIfPalindrome()
        {
            string word = "taco cat";
            bool result = StringMethods.IsPalindrome(word);
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void Palindrome_GivenPalindromeString2_ReturnsIfPalindrome()
        {
            string word = "some men interpret nine memos";
            bool result = StringMethods.IsPalindrome(word);
            Assert.IsTrue(result);
        }

        public void Palindrome_GivenPalindromeString3_ReturnsIfPalindrome()
        {
            string word = "289982";
            bool result = StringMethods.IsPalindrome(word);
            Assert.IsTrue(result);
        }

        public void Palindrome_GivenPalindromeString4_ReturnsIfPalindrome()
        {
            string word = "1234321";
            bool result = StringMethods.IsPalindrome(word);
            Assert.IsTrue(result);
        }

        public void Palindrome_GivenPalindromeString5_ReturnsIfPalindrome()
        {
            string word = "never odd or even";
            bool result = StringMethods.IsPalindrome(word);
            Assert.IsTrue(result);
        }

        public void Palindrome_GivenNonPalindromeString1_ReturnsIfPalindrome()
        {
            string word = "This is not a palindrome";
            bool result = StringMethods.IsPalindrome(word);
            Assert.IsFalse(result);
        }

        public void Palindrome_GivenNonPalindromeString2_ReturnsIfPalindrome()
        {
            string word = "1 test for numerics";
            bool result = StringMethods.IsPalindrome(word);
            Assert.IsFalse(result);
        }
        #endregion

        #region Problem 3 Test Cases
        [TestMethod]
        public void JSONMapper_GivenPayLoadAndMapping_ReturnsFinalMapping()
        {
            string jsonPayLoad = @"{'Name':'Hello','This' : {'That' : {'TheOther' : 'There'}}}";
            string jsonMappings = @"{'Test_Name' : 'Name','Test_Value' : 'This.That.TheOther'}";

            JSONMapper m = new JSONMapper();
            string json = m.JSONStringMap(jsonPayLoad, jsonMappings);
            Assert.AreEqual(@"{""Test_Name"":""Hello"",""Test_Value"":""There""}", json);
        }
        #endregion

        #region Problem 7 Test Cases
        [TestMethod]
        public void ThreadSafeCollection_AddingOneElement_ReturnsCollectionSizeOne()
        {
            ThreadSafeCollection ts = new ThreadSafeCollection();
            ts.Add("Name", "Christopher Tufaro");
            Assert.IsTrue(ts.Count() == 1);
        }

        [TestMethod]
        public void ThreadSafeCollection_AddingTwoElements_ReturnsCollectionSizeTwo()
        {
            ThreadSafeCollection ts = new ThreadSafeCollection();
            ts.Add("Name", "Christopher Tufaro");
            ts.Add("Gender", "Male");
            Assert.IsTrue(ts.Count() == 2);
        }

        [TestMethod]
        public void ThreadSafeCollection_AddingOneElementsThanDeleting_ReturnsCollectionSizeZero()
        {
            ThreadSafeCollection ts = new ThreadSafeCollection();
            ts.Add("Name", "Christopher Tufaro");
            ts.Delete("Name");
            Assert.IsTrue(ts.Count() == 0);
        }

        [TestMethod]
        public void ThreadSafeCollection_AddingOneElementsThanUpdating_ReturnsCollectionWithUpdatedElement()
        {
            ThreadSafeCollection ts = new ThreadSafeCollection();
            ts.Add("Name", "Christopher Tufaro");
            ts.Update("Name", "Chris Tufaro");
            KeyValuePair<string, object> ret = ts.Get("Name");
            Assert.AreEqual("Chris Tufaro", ret.Value);
        }
        #endregion
    }
}
