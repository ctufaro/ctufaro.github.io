﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlphaPoint.ClassLibrary
{
    public class ThreadSafeCollection
    {
        internal ICollection<KeyValuePair<string,object>> collection;

        public ThreadSafeCollection()
        {
            collection = new Dictionary<string, object>();
        }

        public void Add(string key, object value)
        {
            lock (collection)
            {
                collection.Add(new KeyValuePair<string, object>(key, value));
            }
        }

        public void Delete(string key)
        {
            lock (collection)
            {
                collection.Remove(Get(key));
            }
        }

        public void Update(string key, object value)
        {
            lock (collection)
            {
                collection.Remove(Get(key));
                collection.Add(new KeyValuePair<string, object>(key, value));
            }
        }

        public int Count()
        {
            lock (collection)
            {
                return collection.Count;
            }
        }

        public KeyValuePair<string, object> Get(string key)
        {
            lock (collection)
            {
                foreach (KeyValuePair<string, object> kvp in collection)
                {
                    if (kvp.Key.Equals(key))
                    {
                        return kvp;
                    }
                }

                return new KeyValuePair<string, object>();
            }
            
        }
    }
}
