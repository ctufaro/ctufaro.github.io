﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlphaPoint.ClassLibrary
{
    public class StringMethods
    {
        public static string Interverse(string word)
        {
            if (!string.IsNullOrEmpty(word))
            {
                word = word.Trim();
                StringBuilder iversed = new StringBuilder();
                iversed.Append(word[0]);
                for (int i = 1; i < word.Length; i++)
                {
                    iversed.Append(word[word.Length - (i)]);
                    iversed.Append(word[i]);
                }
                iversed.Append(word[0]);
                return iversed.ToString();
            }
            else
            {
                return string.Empty;
            }
        }

        public static bool IsPalindrome(string word)
        {
            word = word.Trim().Replace(" ", "");
            int head = 0;
            int tail = word.Length - 1;
            while(head < tail)
            {
                if (!word[head].Equals(word[tail]))
                    return false;
                head++;
                tail--;
            }
            return true;

        }

    }
}
