﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Text;

namespace AlphaPoint.ClassLibrary
{
    public class JSONMapper
    {
        public string JSONStringMap(string jsonPayLoad, string jsonMappings)
        {
            var jsonPayLoadParsed = JToken.Parse(jsonPayLoad);
            var jsonMappingsParsed = JToken.Parse(jsonMappings);

            var jsonPayDict = CollectFields(jsonPayLoadParsed, new Dictionary<string, JValue>());
            var jsonMapDict = CollectFields(jsonMappingsParsed, new Dictionary<string, JValue>());

            Dictionary<string, string> jsonOutPutDict = new Dictionary<string, string>();
            foreach (string key in jsonMapDict.Keys)
            {
                jsonOutPutDict.Add(key, jsonPayDict[jsonMapDict[key].ToString()].ToString());
            }

            return JsonConvert.SerializeObject(jsonOutPutDict);
        }

        private Dictionary<string, JValue> CollectFields(JToken jToken, Dictionary<string, JValue> fields)
        {
            //recursive call iterating through Objects, Arrays, and Properties
            //reference: https://riptutorial.com/csharp/example/32164/collect-all-fields-of-json-object
            switch (jToken.Type)
            {
                case JTokenType.Object:
                    foreach (var child in jToken.Children<JProperty>())
                        CollectFields(child, fields);
                    break;
                case JTokenType.Array:
                    foreach (var child in jToken.Children())
                        CollectFields(child, fields);
                    break;
                case JTokenType.Property:
                    CollectFields(((JProperty)jToken).Value, fields);
                    break;
                default:
                    fields.Add(jToken.Path, (JValue)jToken);
                    break;
            }

            return fields;
        }
   
    }
}
