﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace AlphaPoint.ClassLibrary
{
    public class ParallelFileWrite
    {
        public static void Write(string folderPath, string outputFile)
        {
            string[] files = Directory.GetFiles(folderPath);

            using (StreamWriter sw = new StreamWriter(outputFile, true))
            {
                Parallel.ForEach(files, (currentFile) =>
                {
                    using (StreamReader sr = new StreamReader(currentFile))
                    {
                        while (!sr.EndOfStream)
                            sw.WriteLine(sr.ReadLine());
                    }
                });
            }
        }
    }
}
