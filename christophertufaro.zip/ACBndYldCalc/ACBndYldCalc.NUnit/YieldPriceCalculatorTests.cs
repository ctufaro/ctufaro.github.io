﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ACBndYldCalc.WPF.Controller;

namespace ACBndYldCalc.NUnit
{
    [TestFixture]
    public class YieldPriceCalculatorTests
    {
        [Test]
        public void CalculatePrice_With10PercentCouponFor5Years1000Dollars()
        {
            //Arrange
            YieldPriceCalculatorController calc = new YieldPriceCalculatorController();
            
            //Act
            var price = calc.CalcPrice(.10, 5, 1000, .15);

            //Assert
            Assert.AreEqual(832.3922451, price);
        }

        [Test]
        public void CalculateYield_With10PercentCouponFor5Years1000Dollars()
        {
            YieldPriceCalculatorController calc = new YieldPriceCalculatorController();
            var yield = calc.CalcYield(.10, 5, 1000, 832.4);
            Assert.AreEqual(0.1499974, yield);
        }

        [Test]
        public void CalcuatePrice_With15PercentCouponFor5Years1000Dollars()
        {
            YieldPriceCalculatorController calc = new YieldPriceCalculatorController();
            var price = calc.CalcPrice(.15, 5, 1000, .15);
            Assert.AreEqual(1000.0000000, price);
        }

        [Test]
        public void CalculateYield_SecondExample_With10PercentCouponFor5Years1000Dollars()
        {
            YieldPriceCalculatorController calc = new YieldPriceCalculatorController();
            var yield = calc.CalcYield(0.10, 5, 1000, 1000);
            Assert.AreEqual(0.1000000, yield);
        }

        [Test]
        public void CalculatePrice_PremiumBonds_With10PercentCouponFor5Years1000Dollars()
        {
            YieldPriceCalculatorController calc = new YieldPriceCalculatorController();
            var price = calc.CalcPrice(0.10, 5, 1000, 0.08);
            Assert.AreEqual(1079.8542007, price);
        }

        [Test]
        public void CalculateYield_PremiumBonds_With10PercentCouponFor5Years1000Dollars()
        {
            YieldPriceCalculatorController calc = new YieldPriceCalculatorController();
            var yield = calc.CalcYield(0.10, 5, 1000, 1079.85);
            Assert.AreEqual(0.080001, yield);
        }

        [Test]
        public void CalculatePrice_ConsistentCheck_With10PercentCouponFor30Years1000Dollars()
        {
            YieldPriceCalculatorController calc = new YieldPriceCalculatorController();
            var price = calc.CalcPrice(0.10, 30, 1000, 0.19);
            Assert.AreEqual(528.8807463, price);
        }

        [Test]
        public void CalculateYield_ConsistentCheck_With10PercentCouponFor5Years1000Dollars()
        {
            YieldPriceCalculatorController calc = new YieldPriceCalculatorController();
            var yield = calc.CalcYield(0.10, 30, 1000, 528.8807463);
            Assert.AreEqual(0.1900000, yield);
        }

    }
}
