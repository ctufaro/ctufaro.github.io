﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ACBndYldCalc.WPF.Controller;
using ACBndYldCalc.Library.Exceptions;

namespace ACBndYldCalc.NUnit
{
    [TestFixture]
    public class YieldPriceCustomExceptionTests
    {
        [Test]
        public void CustomException_ThrowYieldCalculationException_Return_CustomException()
        {
            YieldPriceCalculatorController calc = new YieldPriceCalculatorController();
            Action failingInvocation = () => { calc.CalcYield(.1, 5, 1000, 8000); };
            AssertExtension.Throws<YieldCalculationException>(failingInvocation);
        }

        #region Exception Thrower Helper
        public class AssertExtension
        {
            public static T Throws<T>(Action expressionUnderTest,
                                      string exceptionMessage = "Expected exception has not been thrown by target of invocation."
                                     ) where T : Exception
            {
                try
                {
                    expressionUnderTest();
                }
                catch (T exception)
                {
                    return exception;
                }

                Assert.Fail(exceptionMessage);
                return null;
            }
        }
        #endregion
    }
}
