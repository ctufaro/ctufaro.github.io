﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ACBndYldCalc.Library.Exceptions
{
    /// <summary>
    /// Custom exception to handle approximation errors
    /// </summary>
    public class YieldCalculationException : Exception
    {
        public YieldCalculationException(string message)
            : base(String.Format("Yield Calculation Exception: {0}", message))
        {
        }
    }

}
