﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ACBndYldCalc.Interfaces;
using ACBndYldCalc.Library.Exceptions;

namespace ACBndYldCalc.WPF.Controller
{
    public class YieldPriceCalculatorController : ICalculator
    {
        /// <summary>
        /// Bond Price Valuation of a trading bond        
        /// </summary>
        /// <param name="coupon">The coupon interest rate</param>
        /// <param name="years">The number of years</param>
        /// <param name="face">The bond par value, or the value when the bond matures</param>
        /// <param name="rate">The discount rate</param>
        /// <returns></returns>
        /// sourced ref. https://github.com/panth0r/BondPriceYield/blob/master/WoodsPriceYieldCalc/Calculators.cs
        public double CalcPrice(double coupon, int years, double face, double rate)
        {
            try
            {
                double price = 0;
                double payment = face * coupon;
                for (int year = 1; year <= years; year++)
                {
                    price += payment / (Math.Pow(1 + rate, year));
                }
                price += face / (Math.Pow(1 + rate, years));
                return Math.Round(price, 7);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Bond Yield calculation (Utilizes while loop for best rate appoximation)
        /// </summary>
        /// <param name="coupon">The coupon payment</param>
        /// <param name="years">The number of years</param>
        /// <param name="face">The bond par value, or the value when the bond matures</param>
        /// <param name="price">The price the bond is being sold at</param>
        /// <returns></returns>
        /// sourced ref. https://github.com/panth0r/BondPriceYield/blob/master/WoodsPriceYieldCalc/Calculators.cs
        public double CalcYield(double coupon, int years, double face, double price)
        {
            int iterationCheck = 0;
            double rate = 0;
            double payment = coupon * face;
            double epsilon = 1;
            rate = (payment + ((face - price) / years)) / ((face + price) / 2);
            double estPrice = CalcPrice(coupon, years, face, rate);
            while (Math.Abs(estPrice - price) > 0.0000001)
            {
                if (estPrice > price)
                {
                    rate += epsilon;
                    estPrice = CalcPrice(coupon, years, face, rate);
                }
                else
                {
                    rate -= epsilon;
                    estPrice = CalcPrice(coupon, years, face, rate);
                }
                epsilon = epsilon / 2;

                if (iterationCheck++ > 1000)
                    throw new YieldCalculationException("Exceeded Approximations");
            }
            return Math.Round(rate, 7);
        }
    }
}
