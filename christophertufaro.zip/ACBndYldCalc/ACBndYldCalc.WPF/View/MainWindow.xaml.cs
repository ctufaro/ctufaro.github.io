﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ACBndYldCalc.Library.Logger;
using ACBndYldCalc.Library.Exceptions;
using ACBndYldCalc.WPF.Controller;

namespace ACBndYldCalc.WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private YieldPriceCalculatorController calc;
        private SimpleLogger logger;
        private static readonly Regex regex = new Regex("[^0-9.-]+"); //regex that matches disallowed text
        private double coupon;
        private int years;
        private double face;
        private double rate;
        private double price;

        public MainWindow()
        {
            calc = new YieldPriceCalculatorController();
            logger = new SimpleLogger();
            InitializeComponent();
        }

        private void btnCalculatePrice_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double.TryParse(txtCoupon.Text, out coupon);
                Int32.TryParse(txtYears.Text, out years);
                double.TryParse(txtFace.Text, out face);
                double.TryParse(txtRate.Text, out rate);
                txtCalculatedPrice.Text = calc.CalcPrice(coupon, years, face, rate).ToString();
                txtErrorMessage.Text = string.Empty;
            }
            catch (Exception ex)
            {
                txtErrorMessage.Text = "Calculation Error!";
                logger.Error(ex.ToString());
            }
        }



        private void btnCalculateYield_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double.TryParse(txtCoupon.Text, out coupon);
                Int32.TryParse(txtYears.Text, out years);
                double.TryParse(txtFace.Text, out face);
                double.TryParse(txtPrice.Text, out price);
                txtCalculatedYield.Text = calc.CalcYield(coupon, years, face, price).ToString();
                txtErrorMessage.Text = string.Empty;
            }
            catch (YieldCalculationException ex)
            {
                txtErrorMessage.Text = "Yield Calculation Error!";
                logger.Error(ex.ToString());
            }
            catch (Exception ex)
            {
                txtErrorMessage.Text = "Calculation Error!";
                logger.Error(ex.ToString());
            }
        }

        private static bool IsTextAllowed(string text)
        {
            return !regex.IsMatch(text);
        }


        private void txtHelp_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            if (e.KeyboardDevice.IsKeyDown(Key.Tab))
                ((TextBox)sender).SelectAll();
        }

        private void txtHelp_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsTextAllowed(e.Text);
        }
    }
}
